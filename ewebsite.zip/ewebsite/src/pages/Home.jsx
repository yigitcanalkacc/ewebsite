import React from 'react';
import '../css/home.css';

function Home() {
    return (
        <div className="home-container">

            {/* Resim Bölümü */}
            <div className="images-section">
                <img src="https://picsum.photos/id/1018/550/250/" alt="Image 1" className="image-item" />
                <img src="https://picsum.photos/id/1015/550/250/" alt="Image 2" className="image-item" />
                <img src="https://picsum.photos/id/1019/550/250/" alt="Image 3" className="image-item" />
            </div>

            {/* Öne Çıkan Ürünler Başlığı */}
            <div className="section-title">
                <h2>Öne Çıkan Ürünler</h2>
            </div>

            {/* Ürünler Bölümü */}
            <div className="products">
                <div className="product-card">
                    <img src="https://images.unsplash.com/photo-1596495577883-cdb76bb1b4eb?crop=entropy&cs=tinysrgb&fit=max&ixid=MnwzNjUyOXwwfDF8c2VhY2h8MjF8fGVjb21tZXJjZSUyMGZvb2QlMjBvcHB8ZW58MHx8fHwxNjY2NzA3MTY3&ixid=rb-1.2.1&q=80&w=1080" alt="Product 1" />
                    <h3>Ürün Adı 1</h3>
                    <p>Ürün açıklaması burada yer alacak.</p>
                    <button className="buy-btn">Satın Al</button>
                </div>
                <div className="product-card">
                    <img src="https://images.unsplash.com/photo-1605936889798-3c4eb516ff28?crop=entropy&cs=tinysrgb&fit=max&ixid=MnwzNjUyOXwwfDF8c2VhY2h8MjN8fGVjb21tZXJjZSUyMGZvb2QlMjBvcHB8ZW58MHx8fHwxNjY2NzA3MTY3&ixid=rb-1.2.1&q=80&w=1080" alt="Product 2" />
                    <h3>Ürün Adı 2</h3>
                    <p>Ürün açıklaması burada yer alacak.</p>
                    <button className="buy-btn">Satın Al</button>
                </div>
                <div className="product-card">
                    <img src="https://images.unsplash.com/photo-1606112212079-9ea3a9d3fa7b?crop=entropy&cs=tinysrgb&fit=max&ixid=MnwzNjUyOXwwfDF8c2VhY2h8MjN8fGVjb21tZXJjZSUyMGZvb2QlMjBvcHB8ZW58MHx8fHwxNjY2NzA3MTY3&ixid=rb-1.2.1&q=80&w=1080" alt="Product 3" />
                    <h3>Ürün Adı 3</h3>
                    <p>Ürün açıklaması burada yer alacak.</p>
                    <button className="buy-btn">Satın Al</button>
                </div>
            </div>

            {/* Footer */}
            <footer className="footer">
                <p>&copy; Test Website / @yigitcanalkacc</p>
            </footer>
        </div>
    );
}

export default Home;
