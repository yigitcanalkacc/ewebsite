import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import axios from 'axios';

const initialState = {
    product: [],
    selectedProduct: {}
}

const URL = "https://fakestoreapi.com"
export const getAllProduct = createAsyncThunk("getAllProducts", async () => {
    const response = await axios.get(`${URL}/products`)
    return response.data
})

export const productSlice = createSlice({
    name: "product",
    initialState,

    reducers: {

    },
    extraReducers: (builder) => {
        builder.addCase(getAllProduct.fulfilled, (state, action) => {
            state.product = action.payload;
        })
    }

})

export const { } = productSlice.actions

export default productSlice.reducer