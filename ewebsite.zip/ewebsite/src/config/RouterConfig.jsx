import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Home from '../pages/Home'
import ProductDetails from '../component/ProductDetails'
import ProductList from '../component/ProductList'



function RouterConfig() {
    return (
        <Routes >
            <Route path='/' element={<Home />} />
            <Route path='/product/' element={<ProductList />} />
            <Route path='/products-details/:id' element={<ProductDetails />} />
        </Routes>
    )
}

export default RouterConfig
