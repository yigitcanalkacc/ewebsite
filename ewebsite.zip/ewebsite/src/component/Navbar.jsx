import React from 'react';
import { Link, NavLink } from 'react-router-dom';  // NavLink import ediliyor
import '../css/navbar.css';

function Navbar() {
    return (
        <div className='main-page'>
            <ul style={{ display: 'flex', padding: 0, margin: 0 }}>
                <li><NavLink to="/" exact activeClassName="active">Anasayfa</NavLink></li>
                <li><NavLink to="/product" activeClassName="active">Ürünler</NavLink></li>
                <li><NavLink to="/contact" activeClassName="active">İletişim</NavLink></li>
                <li><NavLink to="/other" activeClassName="active">Diğer</NavLink></li>
            </ul>
        </div>
    );
}

export default Navbar;
