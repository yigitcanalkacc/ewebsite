import React from 'react';
import '../css/product.css'
import { useNavigate } from 'react-router-dom'

function Product({ product }) {
    if (!product) {
        console.log('Product component - product is undefined:', product);
        return <div></div>;
    }

    const { id, image, title, price, description } = product;
    const navigate = useNavigate()

    return (
        <div className="product" key={id}>
            <img src={image} alt={title} className="product-image" />
            <h2 className="product-title">{title}</h2>
            <p className="product-description">{description}</p>
            <p className="product-price">{`Fiyat: $${price}`}</p>

            <div onClick={() => navigate("/products-details/" + id)} className='detay-git'>
                <p>Detayına Git</p>
            </div>
        </div>

    );
}

export default Product;
