import React from 'react'
import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getAllProduct } from '../redux/slices/ProductSlices'
import { store } from '../redux/store';
import Product from './Product';


function ProductList() {

    const dispatch = useDispatch();
    const { product } = useSelector((store) => store.product)


    useEffect(() => {
        dispatch(getAllProduct())
    }, [])

    return (
        <div>
            {
                product && product.map((product) => (
                    <Product key={product.id} product={product} />
                ))
            }

        </div>
    )
}

export default ProductList
