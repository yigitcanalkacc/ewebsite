import { useState } from 'react'
import './App.css'
import Navbar from './component/Navbar'
import ProductList from './component/ProductList'
import RouterConfig from './config/RouterConfig'
import Product from './component/Product'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div>
      <Navbar />

      <RouterConfig />
      <Product />
    </div>
  )
}

export default App
